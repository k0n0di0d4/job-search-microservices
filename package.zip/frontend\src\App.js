import {BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './auth/Login.jsx';
import Register from './auth/Register.jsx';
import JobList from './job/JobList.jsx';
import RequireAuth from "./auth/RequireAuth.jsx";

function App() {
  return (
      <Router>
        <Routes>
          <Route path="/login" element={<Login/>} />
          <Route path="/register" element={<Register/>} />
          <Route path="/jobs" element={
              <RequireAuth>
                  <JobList/>
              </RequireAuth>
          } />
          <Route path="/" element={<Navigate to="/jobs"/>} />
        </Routes>
      </Router>
  );
}

export default App;
