package org.filipscode.job_listing_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobListingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
