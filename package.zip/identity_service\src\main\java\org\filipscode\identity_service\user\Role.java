package org.filipscode.identity_service.user;

public enum Role {
    USER, ADMIN
}
